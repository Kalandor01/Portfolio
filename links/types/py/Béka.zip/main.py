
def imput(sz=""):
    try:
        x = int(input(sz))
    except ValueError:
        x = -1
        print("Nem szám!")
    return x


def write(li):
    print()
    for x in range(len(li)):
        print(x + 1, end=" ")
    print()
    for lo in li:
        print(lo, end=" ")
    print("\n")


def modify(li):
    res = False
    move_i = -2
    while not (-1 <= move_i < len(li)):
        move_i = imput("Béka száma(0 = újrakezd): ") - 1
        if move_i == -1:
            res = True
        elif not (0 <= move_i < len(li)):
            print("Nem jó béka szám!")
    if not res:
        move = -1
        while not (0 <= move <= 1):
            move = imput("Mozgási stílusa(0 = lépés, 1 = ugrás): ")
            if not (0 <= move <= 1):
                print("Nem jó mozgási stílus!")
        if li[move_i] == "x" and li[move_i - 1 - move] == " ":
            st = li[move_i]
            li[move_i] = " "
            li[move_i - 1 - move] = st
        elif li[move_i] == "o" and move_i + 1 + move < len(li) and li[move_i + 1 + move] == " ":
            st = li[move_i]
            li[move_i] = " "
            li[move_i + 1 + move] = st
        else:
            print("\nIde nem mehet ez a béka!")
        write(li)
    los = True
    for xx in range(len(li)):
        if (li[xx] == "x" and (li[xx - 1] == " " or li[xx - 2] == " ")) or (li[xx] == "o" and (li[xx + 1] == " " or li[xx + 2] == " ")):
            los = False
    if los:
        new = input("\nVesztettél! Újra?(y/n): ")
        if new.upper() == "Y":
            res = True
    return li, res, los


reset = True
while reset:
    reset = False
    lost = False
    lis = ["o", "o", "o", " ", "x", "x", "x"]
    write(lis)
    while lis != ["x", "x", "x", " ", "o", "o", "o"] and not reset and not lost:
        lis, reset, lost = modify(lis)
    if not reset and not lost:
        neww, reset, lost = input("\nNyertél! Újra?(y/n): ")
        if neww.upper() == "Y":
            reset = True
