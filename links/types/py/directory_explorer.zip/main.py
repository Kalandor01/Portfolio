import os

x = 0
d = 0
load_speed = 10000
dot_num = 3
f = open("files.txt", "w")
for root, dirs, files in os.walk("/"):
    for name in files:
        try:
            f.write(os.path.join(root, name) + "\n")
        except UnicodeEncodeError:
            f.write("[UnicodeEncodeError]\n")
            print("\rERROR!!!")
        x += 1
        x = x % load_speed
        if x % load_speed == 0:
            d += 1
            d = d % (dot_num + 1)
            print("\rLoading", end="")
            for _ in range(d):
                print(".", end="")
    for name in dirs:
        try:
            f.write(os.path.join(root, name) + "\n")
        except UnicodeEncodeError:
            f.write("[UnicodeEncodeError]\n")
            print("\rERROR!!!")
        x += 1
        x = x % load_speed
        if x % load_speed == 0:
            d += 1
            d = d % (dot_num + 1)
            print("\rLoading", end="")
            for _ in range(d):
                print(".", end="")
f.close()
