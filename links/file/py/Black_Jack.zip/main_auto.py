﻿import random as r


seed = -1000000000000
r.seed(seed)

f = open("max_cards.txt", "w")
f.close()
lap_max = 0
max_seed = seed
pre_seed = 0
while True:
    f = open("max_cards.txt", "a")
    for _ in range(10):
        for _ in range(100000):
            done = False
            szum = 0
            lap_n = 0
            sim_num_left = []
            for _ in range(13):
                sim_num_left.append(4)
            while not done:
                good = False
                while not good:
                    good = True
                    lap = r.randint(0, 12)
                    if sim_num_left[lap] == 0:
                        good = False
                    else:
                        r.randint(0, sim_num_left[lap] - 1)
                        sim_num_left[lap] -= 1
                        if lap == 0:
                            if szum < 12:
                                szum += 10
                            else:
                                szum += 1
                        elif 10 <= lap <= 12:
                            szum += 10
                        else:
                            szum += lap + 1
                lap_n += 1
                if szum < 21:
                    done = False
                else:
                    done = True
                    if szum == 21:
                        if lap_n >= lap_max:
                            lap_max = lap_n
                            max_seed = seed
            seed += 1
            r.seed(seed)
        print(".")
    print(f"{lap_max}: {max_seed}")
    if max_seed != pre_seed:
        pre_seed = max_seed
        f.write(f"{lap_max}: {max_seed}\n")
    f.close()
