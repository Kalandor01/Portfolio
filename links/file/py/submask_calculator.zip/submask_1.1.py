

file = False
good = True
done = False
meta_done = False
begin_ip = ""
ip = []
ip_cut = ""
halozat_h = []
halozat = []
mask = []
ip_b2 = 0
meret_h = 0
line_n = 0

file_q = input("Read from file(in.txt)?(Y/N): ")
if file_q.upper() == "Y":
    file = True

try:
    f = open("in.txt", "r")
except FileNotFoundError:
    print("No file!\n(Create \"in.txt\" in the project folder)")
    good = False
if good:
    for line in f:
        line = line.replace("\n", "")
        if line != "":
            if line_n == 0:
                begin_ip = line
            else:
                halozat.append(int(line))
            line_n += 1
if file:
    f.close()


# ip cím
while not done and good:
    done = True
    elozo = 0
    ip = []
    if not file:
        begin_ip = input("Beggining IP address: ")
    for x in range(len(begin_ip)):
        if begin_ip[x].find(".") != -1:
            ip.append(int(begin_ip[elozo:x]))
            elozo = x + 1
    ip.append(int(begin_ip[elozo:len(begin_ip)]))
    for x in range(len(ip)):
        if not(-1 < ip[x] < 256):
            done = False
    if len(ip) != 4:
        done = False
    if not done:
        print("Wrong IP address")
        if file:
            good = False
if good:
    for x in range(3):
        ip_cut += str(ip[x]) + "."

# alhálózatok
while not meta_done and good:
    meta_done = True
    meret_2 = 0
    hal_n = 0
    mask = []
    done = False
    while not done:
        if not file:
            meret_h = input("Please input the " + str(hal_n + 1) + ". subnetwork's size (if there are no more, write \"N\"): ")
        elif line_n - 2 < hal_n:
            meret_h = "N"
        if str(meret_h).upper() == "N":
            done = True
            hal_n -= 1
            if hal_n <= -1:
                print("Too few subnetworks!")
                meta_done = False
                if file:
                    good = False
        else:
            if not file:
                halozat.append(int(meret_h))
            if not(0 < halozat[hal_n] < 255):
                halozat.pop(hal_n)
                print("Wrong number!")
                if file:
                    good = False
                    done = True
                    meta_done = True
            else:
                halozat_h.append(halozat[hal_n] + 2)
                if halozat_h[hal_n] <= 1:
                    halozat_h[hal_n] = 1
                    mask.append(32)
                if halozat_h[hal_n] <= 2:
                    halozat_h[hal_n] = 2
                    mask.append(31)
                if halozat_h[hal_n] <= 4:
                    halozat_h[hal_n] = 4
                    mask.append(30)
                elif halozat_h[hal_n] <= 8:
                    halozat_h[hal_n] = 8
                    mask.append(29)
                elif halozat_h[hal_n] <= 16:
                    halozat_h[hal_n] = 16
                    mask.append(28)
                elif halozat_h[hal_n] <= 32:
                    halozat_h[hal_n] = 32
                    mask.append(27)
                elif halozat_h[hal_n] <= 64:
                    halozat_h[hal_n] = 64
                    mask.append(26)
                elif halozat_h[hal_n] <= 128:
                    halozat_h[hal_n] = 128
                    mask.append(25)
                else:
                    halozat_h[hal_n] = 256
                    mask.append(24)
                meret_2 += halozat_h[hal_n]
                # only whole numbers as submask beginning?
                # ip_b2 = ip[3] + ((max(halozat_h) - ip[3] % max(halozat_h)) - (max(halozat_h) - ip[3] % max(halozat_h))//max(halozat_h) * max(halozat_h))
                # -ip_b2        V
                if meret_2 > 256 - ip[3]:
                    done = True
                    meta_done = False
                    print("Too much hosts!")
                    if file and not meta_done:
                        meta_done = True
                        good = False
                else:
                    hal_n += 1

if good:
    f = open("out.txt", "w")
# kiírás
if good:
    elozo_ip = ip[3]
    print("\nNetwork address\t\t\t\tHost addresses\t\t\t\tBroadcast address + type\tSubnet mask\n")
    f.write("\nNetwork address\t\t\t\tHost addresses\t\t\t\tBroadcast address + type\tSubnet mask\n\n")
    for x in range(len(halozat_h)):
        for y in range(len(halozat_h)):
            if max(halozat_h) == halozat_h[y]:
                # make constant number strings
                str_ip_0 = str(ip_cut)
                str_ip_1 = str(ip_cut)
                str_ip_2 = str(ip_cut)
                str_ip_3 = str(ip_cut)
                # add last number strings
                str_ip_0 += str(elozo_ip)
                str_ip_1 += str(elozo_ip + 1)
                str_ip_2 += str(elozo_ip + halozat_h[y] - 2)
                str_ip_3 += str(elozo_ip + halozat_h[y] - 1)
                # adjust number strings
                str_ip_0 += (15 - len(str_ip_0)) * " "
                str_ip_1 = (15 - len(str_ip_1)) * " " + str_ip_1
                str_ip_2 += (15 - len(str_ip_2)) * " "
                str_ip_3 = (15 - len(str_ip_3)) * " " + str_ip_3
                print(f"{str_ip_0}\t\t\t{str_ip_1} - {str_ip_2}\t\t{str_ip_3} /{mask[y]}\t\t\t255.255.255.{256 - 2**(32 - mask[y])}")
                f.write(f"{str_ip_0}\t\t\t{str_ip_1} - {str_ip_2}\t\t{str_ip_3} /{mask[y]}\t\t\t255.255.255.{256 - 2**(32 - mask[y])}\n")
                elozo_ip += halozat_h[y]
                halozat_h.pop(y)
                mask.pop(y)
                break
    if good:
        f.close()
readkey = input()
