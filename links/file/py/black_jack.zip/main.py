import random
import time

r = random

"""""""""
huszonegy
A = 1 vagy 11 : amelyik jobb
KJQ = 10
A 2 3 4 5 6 7 8 9 10 J Q K
0 1 2 3 4 5 6 7 8 9 10 11 12
"""""""""


def huz(lap_sum=0):
    lap = r.randint(0, 12)
    if lap == 0:
        if lap_sum < 11:
            value = 11
        else:
            value = 1
        name = "A"
    elif 10 <= lap <= 12:
        value = 10
        if lap == 10:
            name = "J"
        elif lap == 12:
            name = "Q"
        else:
            name = "K"
    else:
        value = lap + 1
        name = str(lap + 1)
    lap_sum += value
    return name, value, lap_sum


def kiir(lap_names, lap_sum, player=True):
    if player:
        print(f"\nLapjaid: ", end="")
        for x in range(len(names)):
            print(names[x], end="")
            if x < len(names) - 1:
                print(", ", end="")
        print(f": {lap_sum}")
    else:
        print(lap_names[len(lap_names) - 1], end="")
    lap_nyer = -1
    if lap_sum < 21:
        if lap_sum < 16:
            ans = "y"
            time.sleep(0.5)
            if not player:
                print(", ", end="")
        elif player:
            ans = input("Húzol még?(y/n): ")
        else:
            ans = "N"
        if ans != "Y" and ans != "y":
            lap_done = True
        else:
            lap_done = False
    else:
        lap_done = True
        if lap_sum == 21:
            if player:
                print("\nNyertél!\n")
            lap_nyer = 1
        else:
            if player:
                print("\nVesztettél!\n")
            lap_nyer = 0
    return lap_done, lap_nyer, lap_sum


reset = True
while reset:
    reset = False
    # játszma
    # te
    done = False
    szum = 0
    nyer = 0
    names = []
    while not done:
        lap_n, lap_e, szum = huz(szum)
        names.append(lap_n)
        done, nyer, szum = kiir(names, szum)
    # robot
    if nyer == -1:
        print("Gép: ", end="")
        done = False
        szum2 = 0
        names = []
        while not done:
            lap_n, lap_e, szum2 = huz(szum2)
            names.append(lap_n)
            done, nyer, szum2 = kiir(names, szum2, False)
        # kiir
        print(f": {szum2}\n")
        if nyer == 0 or szum > szum2:
            print("Nyertél!")
        elif szum < szum2:
            print("Vesztettél!")
        else:
            print("Döntetlen!")
    new = input("Újra?(y/n): ")
    if new == "y" or new == "Y":
        reset = True
