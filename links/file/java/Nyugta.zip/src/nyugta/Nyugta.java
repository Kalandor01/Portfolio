package nyugta;

public class Nyugta
{
    public static void main(String[] args)
    {
        //változók
        //changable
        int[] tetel={5,1,3,5};
        String[] tetelek_h={"kenyér", "tej", "vaj"};
        double kedvezmeny = -0.0;
        String penz = "", tetel_n = "Tétel";
        int extra = 0;
        //not vhangable
        int x = 0, osz = 0, r_osz = 0, szokoz_def = 0, szokoz_n = szokoz_def, length_t = 0, length_o = 0, length_e = 0, length_k = 0, leng_h = 0, tetel_h = 0;
        kedvezmeny = Math.round(kedvezmeny*10.0)/10.0;
        String szokoz = "", cs = "***********", vonal = "-----------", vonal2 = "===========";
        szokoz_def -= penz.length() - 2;
        String[] tetelek;
        tetelek = new String[tetel.length];
        for(x = 0; x < tetelek_h.length; x++)
            tetelek[x] = tetelek_h[x];
        for(x = 0; x < tetel.length; x++)
        {
            if(tetelek[x] == null)
                tetelek[x] = "";
        }
       
        //tétel
        for (x = 0; x < tetel.length; x++)
        {
            r_osz += tetel[x];
        }
        osz = (int) (r_osz * (1.0 - kedvezmeny / 100.0));
        length_t += penz.length() + tetel_n.length() - 5 + Integer.toString(tetel.length).length();
        length_o += penz.length() + Integer.toString(osz).length();
        for(x = 0; x < tetel.length; x++)
        {
            if (leng_h < Integer.toString(tetel[x]).length())
            {
                leng_h = Integer.toString(tetel[x]).length();
            }
            if (tetel_h < tetelek[x].length())
            {
                tetel_h = tetelek[x].length();
            }
        }
        length_t += leng_h;
        length_t += tetel_h;
        //részösszeg
        if(kedvezmeny != 0)
            length_e += penz.length() + Integer.toString(r_osz).length();
        else
            length_e += penz.length() - 1;
        //kedvezmeny length
        if(kedvezmeny > 0)
        {
            if(kedvezmeny % 1 == 0)
                length_k = Integer.toString((int)kedvezmeny).length();
            else
                length_k = Double.toString(kedvezmeny).length();
        }
        else if(kedvezmeny < 0)
        {
            if(kedvezmeny % 1 == 0)
                length_k = Integer.toString((int)kedvezmeny).length() - 7;
            else
                length_k = Double.toString(kedvezmeny).length() - 7;
        }
        else
            length_k = -3;
       
        //extra
        extra += Math.max(Math.max(length_k + 3, length_t - 1), Math.max(length_o - 1, length_e + 1));
        if(extra < 0)
            extra = 0;
        szokoz_def += extra;
        for(x = 0; x < extra; x++)
        {
            cs += "*";
            vonal += "-";
            vonal2 += "=";
        }
        System.out.println("extra: " +extra +"\n\n\n");
       
       
        //BLOKK
        //csillagok
        System.out.printf(cs + "\n");
        //nyugta
        szokoz = "";
        for (int y=0; y < extra / 2; y++)
            szokoz+=" ";
        System.out.printf("   %sNyugta\n", szokoz);
        //csillag
        System.out.println(cs);
        //tételek
        for (x = 0; x < tetel.length; x++)
        {
            szokoz = "";
            szokoz_n = szokoz_def;
            szokoz_n -= Integer.toString(tetel[x]).length() - 3;
            szokoz_n -= tetelek[x].length() + 2;
            szokoz_n -= Integer.toString(x+1).length();
            for (int y=0; y < szokoz_n; y++)
                    szokoz+=" ";
            System.out.printf("%s %d: %s%s%d%s\n", tetel_n, x+1, tetelek[x], szokoz, tetel[x], penz);
        }
        if(kedvezmeny != 0)
        {
        //vonal
        System.out.println(vonal);
        //részösszeg
            szokoz = "";
            szokoz_n = szokoz_def - 5;
            szokoz_n -= Integer.toString(r_osz).length() - 3;
            for (int y=0; y < szokoz_n; y++)
                szokoz+=" ";
            System.out.printf("Részösszeg:%s%d%s\n", szokoz, r_osz, penz);
        }
        //kedvezmény
        //pozitív
        if(kedvezmeny > 0)
        {
            if(kedvezmeny % 1 == 0)
            {
                szokoz = "";
                szokoz_n = szokoz_def - 5;
                szokoz_n -= Double.toString(kedvezmeny).length() - 3 - penz.length();
                for (int y=0; y < szokoz_n; y++)
                    szokoz+=" ";
                System.out.printf("Kedvezmény:%s-%.0f%%\n", szokoz, kedvezmeny);
            }
            else
            {
                szokoz = "";
                szokoz_n = szokoz_def - 5;
                szokoz_n -= Double.toString(kedvezmeny).length() - 1 - penz.length();
                for (int y=0; y < szokoz_n; y++)
                    szokoz+=" ";
                System.out.printf("Kedvezmény:%s-%.1f%%\n", szokoz, kedvezmeny);
            }
        }
        //negatív
        else if(kedvezmeny < 0)
        {
            if(kedvezmeny % 1 == 0)
            {
                szokoz = "";
                szokoz_n = szokoz_def - 5;
                szokoz_n -= Double.toString(-1 * kedvezmeny).length() - 11 - penz.length();
                for (int y=0; y < szokoz_n; y++)
                    szokoz+=" ";
                System.out.printf("Adó:%s%.0f%%\n", szokoz, -1 * kedvezmeny);
            }
            else
            {
                szokoz = "";
                szokoz_n = szokoz_def - 5;
                szokoz_n -= Double.toString(-1 * kedvezmeny).length() - 9 - penz.length();
                for (int y=0; y < szokoz_n; y++)
                    szokoz+=" ";
                System.out.printf("Adó:%s%.1f%%\n", szokoz, -1 * kedvezmeny);
            }
        }
        //vonal
        System.out.println(vonal);
        //összeg
        szokoz = "";
        szokoz_n = szokoz_def - 3;
        szokoz_n -= Integer.toString(osz).length() - 3;
        for (int y=0; y < szokoz_n; y++)
            szokoz+=" ";
        System.out.printf("Összesen:%s%d%s\n", szokoz, osz, penz);
        //vonal 2
        System.out.println(vonal2);
        //dátum
        System.out.println("_______");
        System.out.println(" Dátum");
        //név
        szokoz = "";
        for (int y=0; y < extra; y++)
            szokoz+=" ";
        System.out.printf("    %s_______\n", szokoz);
        System.out.printf("      %sNév\n", szokoz);
        //csillag
        System.out.println(cs);
        //cég
        szokoz = "";
        for (int y=0; y < extra / 2; y++)
            szokoz+=" ";
        System.out.printf("    %sCÉG\n", szokoz);
        //csillag
        System.out.println(cs);
        //System.out.println("****************\n     Nyugt\n****************\nTétel 1    350Ft\nTétel 2    600Ft\nTétel 3     90Ft\n----------------\nÖsszesen: 1040Ft\n================\n_______\n Dátum\n         _______\n           Név\n****************\n        CÉG\n****************");
    }
}