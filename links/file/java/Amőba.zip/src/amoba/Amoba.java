package amoba;

import java.util.Random;

public class Amoba
{
    public static void main(String[] args)
    {
        //changable variables
        int meret[] = {3, 3};
        boolean manipulate = false, double_win = false;
        int win_manipulate = -1;//-1 = X, 0 = DRAW, 1 = O
        //not changable variables
        int x, y, z, win_x, win_o, win, trys = 0, point_at[];
        int[][] table = new int[meret[0]][meret[1]];
        int[] point_h = new int[meret[0]];
        int[] point_v = new int[meret[1]];
        String line, jelek[] = {"X", "·", "O"};
        Random r = new Random();
        do
        {
            if(manipulate)
            {
                trys++;
                System.out.println(trys + ". try:");
            }
            //table population
            for(x=0;x<meret[0];x++)
            {
                //line = "";
                for(y=0;y<meret[1];y++)
                {
                    //table for winner detection
                    table[x][y] = r.nextInt(3);
                    //line += jelek[table[x][y]];
                }
                //table writeout
                //System.out.println("  " + line);
            }
            //point calculation
            point_at = new int[] {0, 0};
            for(x=0;x<meret[0];x++)
            {
                if(meret[0] == meret[1])
                {
                    point_at[0] += table[x][x] - 1;
                    point_at[1] += table[x][meret[0] - 1 - x] - 1;
                }
                point_h[x] = 0;
                for(y=0;y<meret[1];y++)
                {
                    point_h[x] += table[x][y] - 1;
                    point_v[y] = 0;
                    for(z=0;z<meret[0];z++)
                        point_v[y] += table[z][y] - 1;
                }
            }
            //win count
            win_o = 0;
            win_x = 0;
            //at
            if(point_at[0] == -1 * meret[0])
                win_x += 1;
            if(point_at[1] == -1 * meret[0])
                win_x += 1;
            if(point_at[0] == meret[0])
                win_o += 1;
            if(point_at[1] == meret[0])
                win_o += 1;
            //h
            for(x=0;x<meret[0];x++)
            {
                if(point_h[x] == -1 * meret[1])
                    win_x += 1;
                else if(point_h[x] == meret[1])
                    win_o += 1;
            }
            //v
            for(x=0;x<meret[1];x++)
            {
                if(point_v[x] == -1 * meret[0])
                    win_x += 1;
                else if(point_v[x] == meret[0])
                    win_o += 1;
            }
            //winner
            if(win_x > win_o)
                win = -1;
            else if(win_x == win_o)
                win = 0;
            else
                win = 1;
        }
        while((manipulate == true  && win != win_manipulate) || ((win_x > 1 || win_o > 1) && double_win == false));
        //write
        /*System.out.println();
        for(x=0;x<point_h.length;x++)
            System.out.print(point_h[x] + ", ");
        System.out.println();
        for(x=0;x<point_v.length;x++)
            System.out.print(point_v[x] + ", ");
        System.out.println();
        for(x=0;x<point_at.length;x++)
            System.out.print(point_at[x] + ", ");*/
        //table write
        System.out.println();
        for(x=0;x<meret[0];x++)
        {
            line = "";
            for(y=0;y<meret[1];y++)
                line += jelek[table[x][y]];
            System.out.println("  " + line);
        }
        //winner
        if(win==0)
            System.out.print("\nDRAW: ");
        else
            System.out.print("\n" + jelek[win + 1] + " WINS: ");
        System.out.println(win_x + " - " + win_o + "\n");
    }
}
