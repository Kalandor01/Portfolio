package itt_a_piros;
import java.util.Random;
public class Itt_a_piros {
    public static void main(String[] args)
    {
        //változók
        //changable
        int cup_n = 153, guess_n = 5, guess = 2, wrapping_num = 40;
        boolean wrapping = true;
        //not changable
        int x = 0, y = 0, ans = 0;
        String cups = "", cups_num = "";
        Random r = new Random();
        for(x = 0; x < cup_n; x++)
        {
            for(y = 0; y < Integer.toString(x + 1).length() ; y++)
                cups += "_";
            cups += "  ";
            cups_num += x + 1 +"  ";
            if(x % 40 == 0 && x == 1)
            {
                cups += "\n";
                cups_num += "\n";
            }
        }
        System.out.printf("\nVálassz eggyet:\n%s\n%s\n", cups, cups_num);
        for(x = 0; x < guess_n; x++)
        {
            ans = r.nextInt(cup_n) + 1;
            System.out.printf("\nTipp: %s", guess);
            if(guess == ans)
            {
                System.out.printf("\nTalált: %s->%s\n", guess, ans);
                x = 5;
            }
            else
            {
                System.out.printf("\nNem talált: %s->%s\n", guess, ans);
            }
        }
    }
}
